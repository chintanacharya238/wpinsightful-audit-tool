---
name: Bug report
about: Report a reproducible problem
 title: "[Bug]: "
labels: bug
assignees: ''
---

## Summary
Describe the problem.

## Environment
- WordPress version:
- PHP version:
- Theme/plugins relevant to the issue:
- Hosting/cache setup (no private details):

## Steps to reproduce
1.
2.
3.

## Expected behaviour

## Actual behaviour

## Logs or screenshots
Remove secrets, personal information, and private URLs before sharing.
