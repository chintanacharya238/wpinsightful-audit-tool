<?php
/**
 * Plugin Name: WPInsightful Audit Tool
 * Description: A lightweight, early-stage homepage quality checker for WordPress administrators.
 * Version: 0.1.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Chintan Acharya
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wpinsightful-audit-tool
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/** Register the audit page. */
function wia_register_admin_page() {
    add_management_page(
        __( 'WPInsightful Audit', 'wpinsightful-audit-tool' ),
        __( 'WPInsightful Audit', 'wpinsightful-audit-tool' ),
        'manage_options',
        'wpinsightful-audit-tool',
        'wia_render_admin_page'
    );
}
add_action( 'admin_menu', 'wia_register_admin_page' );

/** Run the lightweight checks after a nonce-verified administrator action. */
function wia_handle_audit_request() {
    if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
        return;
    }

    if ( empty( $_POST['wia_run_audit'] ) ) {
        return;
    }

    check_admin_referer( 'wia_run_audit_action', 'wia_nonce' );
    $url = home_url( '/' );

    // Only request the site's own configured homepage; avoid arbitrary URL fetching.
    $response = wp_safe_remote_get(
        $url,
        array(
            'timeout'             => 12,
            'redirection'         => 3,
            'limit_response_size' => 1500000,
            'user-agent'          => 'WPInsightfulAuditTool/0.1.0; ' . home_url( '/' ),
        )
    );

    $results = array();
    $results[] = array(
        'label'   => __( 'Homepage URL uses HTTPS', 'wpinsightful-audit-tool' ),
        'passed'  => 'https' === wp_parse_url( $url, PHP_URL_SCHEME ),
        'details' => $url,
    );

    if ( is_wp_error( $response ) ) {
        $results[] = array(
            'label'   => __( 'Homepage can be fetched', 'wpinsightful-audit-tool' ),
            'passed'  => false,
            'details' => $response->get_error_message(),
        );
        set_transient( 'wia_last_results_' . get_current_user_id(), $results, 5 * MINUTE_IN_SECONDS );
        return;
    }

    $status = (int) wp_remote_retrieve_response_code( $response );
    $html   = (string) wp_remote_retrieve_body( $response );
    $results[] = array(
        'label'   => __( 'Homepage returns HTTP 2xx', 'wpinsightful-audit-tool' ),
        'passed'  => $status >= 200 && $status < 300,
        'details' => sprintf( __( 'HTTP status: %d', 'wpinsightful-audit-tool' ), $status ),
    );

    $title = '';
    if ( preg_match( '/<title\b[^>]*>(.*?)<\/title\s*>/is', $html, $matches ) ) {
        $title = trim( wp_strip_all_tags( html_entity_decode( $matches[1], ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) );
    }
    $results[] = array(
        'label'   => __( 'Page title is present', 'wpinsightful-audit-tool' ),
        'passed'  => '' !== $title,
        'details' => '' !== $title ? $title : __( 'No title element found.', 'wpinsightful-audit-tool' ),
    );

    $description = '';
    if ( preg_match( '/<meta\b[^>]*\bname\s*=\s*(["\'])description\1[^>]*>/is', $html, $meta_match ) ) {
        if ( preg_match( '/\bcontent\s*=\s*(["\'])(.*?)\1/is', $meta_match[0], $content_match ) ) {
            $description = trim( html_entity_decode( $content_match[2], ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
        }
    }
    $results[] = array(
        'label'   => __( 'Meta description is present', 'wpinsightful-audit-tool' ),
        'passed'  => '' !== $description,
        'details' => '' !== $description ? $description : __( 'No meta description found in the fetched HTML.', 'wpinsightful-audit-tool' ),
    );

    preg_match_all( '/<h1\b[^>]*>(.*?)<\/h1\s*>/is', $html, $h1_matches );
    $h1_count = count( $h1_matches[0] );
    $results[] = array(
        'label'   => __( 'At least one H1 heading is present', 'wpinsightful-audit-tool' ),
        'passed'  => $h1_count > 0,
        'details' => sprintf( __( 'H1 elements found: %d', 'wpinsightful-audit-tool' ), $h1_count ),
    );

    preg_match_all( '/<img\b[^>]*>/is', $html, $image_matches );
    $missing_alt = 0;
    foreach ( $image_matches[0] as $image_tag ) {
        if ( ! preg_match( '/\balt\s*=/i', $image_tag ) ) {
            $missing_alt++;
        }
    }
    $results[] = array(
        'label'   => __( 'Images include alt attributes', 'wpinsightful-audit-tool' ),
        'passed'  => 0 === $missing_alt,
        'details' => sprintf( __( '%1$d image(s) without an alt attribute out of %2$d fetched image(s). An empty alt attribute can be correct for decorative images.', 'wpinsightful-audit-tool' ), $missing_alt, count( $image_matches[0] ) ),
    );

    set_transient( 'wia_last_results_' . get_current_user_id(), $results, 5 * MINUTE_IN_SECONDS );
}
add_action( 'admin_init', 'wia_handle_audit_request' );

/** Render the audit page and the most recent results. */
function wia_render_admin_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    $results = get_transient( 'wia_last_results_' . get_current_user_id() );
    ?>
    <div class="wrap">
        <h1><?php esc_html_e( 'WPInsightful Homepage Audit', 'wpinsightful-audit-tool' ); ?></h1>
        <p><?php esc_html_e( 'Run a small set of checks against the homepage configured for this WordPress site. These indicators are not a substitute for a complete SEO, performance, or accessibility audit.', 'wpinsightful-audit-tool' ); ?></p>
        <form method="post">
            <?php wp_nonce_field( 'wia_run_audit_action', 'wia_nonce' ); ?>
            <p><button type="submit" name="wia_run_audit" value="1" class="button button-primary"><?php esc_html_e( 'Run homepage checks', 'wpinsightful-audit-tool' ); ?></button></p>
        </form>
        <?php if ( is_array( $results ) ) : ?>
            <h2><?php esc_html_e( 'Latest results', 'wpinsightful-audit-tool' ); ?></h2>
            <table class="widefat striped">
                <thead><tr><th><?php esc_html_e( 'Check', 'wpinsightful-audit-tool' ); ?></th><th><?php esc_html_e( 'Status', 'wpinsightful-audit-tool' ); ?></th><th><?php esc_html_e( 'Details', 'wpinsightful-audit-tool' ); ?></th></tr></thead>
                <tbody>
                <?php foreach ( $results as $result ) : ?>
                    <tr>
                        <td><?php echo esc_html( $result['label'] ); ?></td>
                        <td><?php echo $result['passed'] ? '<strong style="color:#137333">' . esc_html__( 'Pass', 'wpinsightful-audit-tool' ) . '</strong>' : '<strong style="color:#b32d2e">' . esc_html__( 'Review', 'wpinsightful-audit-tool' ) . '</strong>'; ?></td>
                        <td><?php echo esc_html( $result['details'] ); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
        <p class="description"><?php esc_html_e( 'Note: pages rendered mostly by JavaScript, blocked self-requests, cache layers, or non-standard HTML may affect results. Checks are heuristic and may need manual verification.', 'wpinsightful-audit-tool' ); ?></p>
    </div>
    <?php
}
