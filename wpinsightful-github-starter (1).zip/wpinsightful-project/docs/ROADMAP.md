# WPInsightful Roadmap

This roadmap is a working plan, not a claim that all listed features are implemented. Priorities may change with testing and community feedback.

## Phase 1 — Reliable MVP
- [x] Create an initial plugin scaffold and admin page.
- [x] Add basic homepage checks for HTTPS, HTTP response, title, meta description, H1, and image alt attributes.
- [ ] Test against current WordPress releases, popular SEO plugins, and different hosting configurations.
- [ ] Add automated tests and a documented manual QA checklist.
- [ ] Improve HTML parsing and edge-case handling.

## Phase 2 — Useful reports
- [ ] Group results by SEO basics, technical health, and accessibility hints.
- [ ] Add clearer remediation guidance for each finding.
- [ ] Provide an exportable report with timestamp and site version details.
- [ ] Add configurable checks and explain false positives.

## Phase 3 — Performance and accessibility
- [ ] Add safe, reproducible performance measurements or integrations with established testing services.
- [ ] Expand accessibility guidance while clearly distinguishing automated checks from manual review.
- [ ] Add responsive admin UI and keyboard/accessibility testing.

## Phase 4 — Community and integrations
- [ ] Publish contribution guidelines and issue templates.
- [ ] Evaluate integrations with WordPress REST API, WP-CLI, and external audit APIs where appropriate.
- [ ] Gather feedback from developers and site owners before broadening scope.

## Success measures

Use verifiable measures once data exists: releases, merged pull requests, issue response time, reproducible test coverage, installs/downloads (if publicly distributed), and feedback from testers. Do not report adoption or impact figures until they can be substantiated.
